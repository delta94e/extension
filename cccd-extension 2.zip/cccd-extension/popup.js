// CCCD Extractor - Popup Logic
// Handles data extraction from web page and DOCX generation
// Supports: Section A (Thông tin hành chính) + Section C (Khám thực thể - Chỉ số sinh tồn)

let extractedData = null;

document.addEventListener('DOMContentLoaded', () => {
  const btnExtract = document.getElementById('btnExtract');
  const btnExport = document.getElementById('btnExport');

  btnExtract.addEventListener('click', handleExtract);
  btnExport.addEventListener('click', handleExport);
});

// ============================
// EXTRACT DATA FROM WEB PAGE
// ============================
async function handleExtract() {
  setStatus('loading', 'Đang trích xuất thông tin...');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab) {
      setStatus('error', 'Không tìm thấy tab đang mở');
      return;
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractDataFromPage
    });

    if (results && results[0] && results[0].result) {
      extractedData = results[0].result;
      displayData(extractedData);
      setStatus('success', `Đã trích xuất thành công ${countFilledFields(extractedData)} trường`);
      document.getElementById('btnExport').disabled = false;
    } else {
      setStatus('error', 'Không thể trích xuất dữ liệu. Hãy mở trang tiếp đón bệnh nhân.');
    }
  } catch (error) {
    console.error('Extract error:', error);
    setStatus('error', 'Lỗi: ' + error.message);
  }
}

/**
 * This function runs in the context of the web page (injected via chrome.scripting)
 */
function extractDataFromPage() {
  const data = {};

  // ====== HELPER FUNCTIONS ======
  function getInput(name) {
    const el = document.querySelector(`input[name="${name}"]`);
    return el ? el.value || '' : '';
  }

  function getSelect(fieldName) {
    const container = document.querySelector(`.nz-col-${fieldName}`);
    if (container) {
      const item = container.querySelector('nz-select-item');
      if (item) return item.getAttribute('title') || item.textContent?.trim() || '';
      
      // Fallback: check for radio buttons (important for Giới tính)
      const checkedRadio = container.querySelector('input[type="radio"]:checked');
      if (checkedRadio) {
        const label = checkedRadio.closest('label');
        return label ? label.textContent?.trim() : checkedRadio.value;
      }
      
      const selectedSpan = container.querySelector('.ant-select-selection-item');
      if (selectedSpan) return selectedSpan.getAttribute('title') || selectedSpan.textContent?.trim() || '';
    }
    return '';
  }

  function getDate(fieldName) {
    const container = document.querySelector(`.nz-col-${fieldName}`);
    if (container) {
      const oraInput = container.querySelector('input.ora-input-date');
      if (oraInput && oraInput.value) return oraInput.value;
      const dateInput = container.querySelector('.ant-picker-input input');
      if (dateInput && dateInput.value) return dateInput.value;
      const inputs = container.querySelectorAll('input');
      for (const input of inputs) {
        if (input.value && /\d{2}\/\d{2}\/\d{4}/.test(input.value)) return input.value;
      }
    }
    return '';
  }

  function getFromContainer(fieldName) {
    const container = document.querySelector(`.nz-col-${fieldName}`);
    if (container) {
      // Try regular text input
      const input = container.querySelector('input.ant-input:not(.ant-select-selection-search-input)');
      if (input) return input.value || '';
      // Try nz-input-number
      const numInput = container.querySelector('input.ant-input-number-input');
      if (numInput) return numInput.value || '';
      // Try nz-select-item
      const item = container.querySelector('nz-select-item');
      if (item) return item.getAttribute('title') || item.textContent?.trim() || '';
    }
    return '';
  }

  function getNumberFromContainer(fieldName) {
    const container = document.querySelector(`.nz-col-${fieldName}`);
    if (container) {
      const numInput = container.querySelector('input.ant-input-number-input');
      if (numInput) return numInput.value || '';
      const input = container.querySelector('input.ant-input:not(.ant-select-selection-search-input)');
      if (input) return input.value || '';
    }
    return '';
  }

  // ====== SECTION A: THÔNG TIN HÀNH CHÍNH ======
  // Text inputs
  data.tenDayDu = getInput('tenDayDu');
  data.soNha = getInput('soNha');
  data.dienThoaiDiDong = getInput('dienThoaiDiDong');
  data.cmnd = getInput('cmnd');
  data.maBenhNhan = getInput('maBenhNhan');
  data.tenNguoiThan = getInput('tenNguoiThan');
  data.cmndNguoiThan = getInput('cmndNguoiThan');
  data.dienThoaiNguoiThan = getInput('dienThoaiNguoiThan');

  // Select dropdowns
  data.gioiTinh = getSelect('gioiTinh');
  data.tinhTP = getSelect('tinhId725');
  data.xaPhuong = getSelect('xaId725');
  data.thonXom = getSelect('thonXomId');
  data.danToc = getSelect('danTocId');
  data.quocTich = getSelect('quocTichId');
  data.noiCapCmnd = getSelect('noiCapCmnd');
  data.ngheNghiep = getSelect('ngheNghiepId');
  data.quanHe = getSelect('quanHeId');
  data.nhomDoiTuong = getSelect('nhomDoiTuongId');

  // Date fields
  data.ngaySinh = getDate('ngaySinh');
  data.namSinh = getFromContainer('namSinh');
  data.thangSinh = getFromContainer('thangSinh');
  data.tuoi = getFromContainer('tuoi');
  data.ngayCapCmnd = getDate('ngayCapCmnd');

  // Other
  data.soThe = getFromContainer('soThe');
  data.diaChiLamViec = getInput('diaChiLamViec') || getFromContainer('diaChiLamViec');

  // ====== SECTION C: CHỈ SỐ SINH TỒN (KHÁM THỰC THỂ) ======
  data.mach = getNumberFromContainer('mach');
  data.nhietDo = getNumberFromContainer('nhietDo');
  data.nhipTho = getNumberFromContainer('nhipTho');
  data.canNang = getNumberFromContainer('canNang');
  data.chieuCao = getNumberFromContainer('chieuCao');
  data.vongEo = getNumberFromContainer('vongEo');
  data.duongMau = getNumberFromContainer('duongMau');
  data.bmi = getNumberFromContainer('bmi');

  // Huyết áp - special: 2 inputs in one container (TT/TTr)
  const huyetApContainer = document.querySelector('.nz-col-mach');
  if (huyetApContainer) {
    // There are two nz-col-mach containers; the second one is blood pressure
    const allMach = document.querySelectorAll('.nz-col-mach');
    if (allMach.length >= 2) {
      const bpContainer = allMach[1]; // Second one is Huyết áp
      const bpInputs = bpContainer.querySelectorAll('input.ant-input');
      if (bpInputs.length >= 2) {
        data.huyetApTT = bpInputs[0].value || '';
        data.huyetApTTr = bpInputs[1].value || '';
      } else if (bpInputs.length === 1) {
        data.huyetApTT = bpInputs[0].value || '';
        data.huyetApTTr = '';
      }
    }
  }

  // ====== SECTION D-G: KHÁM LÂM SÀNG & KẾT QUẢ ======
  // Lý do vào viện / Triệu chứng
  data.lyDoVaoVien = getFromContainer('lyDoVaoVien');
  data.trieuChungLamSang = getFromContainer('trieuChungLamSang');
  data.dienBienDieuTri = getFromContainer('dienBienDieuTri');
  data.phuongPhapKhamBenh = getFromContainer('phuongPhapKhamBenh');
  data.ketQuaKham = getFromContainer('ketQuaKham');
  data.tuVanDieuTri = getFromContainer('tuVanDieuTri');
  data.ghiChu = getFromContainer('ghiChu');

  // Bệnh chính & bệnh kèm theo
  data.benhChinh = getSelect('benhChinhId');
  data.dienGiaiBenhChinh = getFromContainer('dienGiaiBenhChinh');
  data.benhKemTheo = getSelect('benhKemTheoId');
  data.dienGiaiBenhKemTheo = getFromContainer('dienGiaiBenhKemTheo');

  // Bác sĩ khám
  data.bacSiKham = getSelect('bacSiKhamId');

  return data;
}

// ============================
// DISPLAY EXTRACTED DATA
// ============================
function displayData(data) {
  // Section A
  document.getElementById('dataSection').style.display = 'block';
  setFieldValue('val_tenDayDu', data.tenDayDu);
  setFieldValue('val_gioiTinh', data.gioiTinh);
  const dateDisplay = data.ngaySinh || [data.thangSinh, data.namSinh].filter(Boolean).join('/');
  setFieldValue('val_ngaySinh', dateDisplay);
  setFieldValue('val_namSinh', data.namSinh);
  setFieldValue('val_cmnd', data.cmnd);
  setFieldValue('val_danToc', data.danToc);
  setFieldValue('val_quocTich', data.quocTich);
  setFieldValue('val_soNha', data.soNha);
  setFieldValue('val_xaPhuong', data.xaPhuong);
  setFieldValue('val_tinhTP', data.tinhTP);
  setFieldValue('val_dienThoaiDiDong', data.dienThoaiDiDong);
  setFieldValue('val_soThe', data.soThe);
  setFieldValue('val_ngheNghiep', data.ngheNghiep);

  // Section C - Vital signs
  document.getElementById('vitalSection').style.display = 'block';
  setFieldValue('val_chieuCao', data.chieuCao ? data.chieuCao + ' cm' : '');
  setFieldValue('val_canNang', data.canNang ? data.canNang + ' kg' : '');
  setFieldValue('val_vongEo', data.vongEo ? data.vongEo + ' cm' : '');
  setFieldValue('val_bmi', data.bmi);
  setFieldValue('val_mach', data.mach ? data.mach + ' lần/phút' : '');
  const bp = (data.huyetApTT && data.huyetApTTr) ? `${data.huyetApTT}/${data.huyetApTTr} mmHg` : '';
  setFieldValue('val_huyetAp', bp);
  setFieldValue('val_nhipTho', data.nhipTho ? data.nhipTho + ' lần/phút' : '');
  setFieldValue('val_duongMau', data.duongMau ? data.duongMau + ' mmol/L' : '');

  // Section D-G - Clinical info
  const hasClinical = data.benhChinh || data.ketQuaKham || data.trieuChungLamSang || data.bacSiKham;
  if (hasClinical) {
    document.getElementById('clinicalSection').style.display = 'block';
    setFieldValue('val_benhChinh', data.benhChinh);
    setFieldValue('val_ketQuaKham', data.ketQuaKham);
    setFieldValue('val_bacSiKham', data.bacSiKham);
  }

  // Show info note about B, D1-D8 sections
  document.getElementById('infoNote').style.display = 'flex';
}

function setFieldValue(id, value) {
  const el = document.getElementById(id);
  if (el) {
    el.textContent = value || '—';
    el.style.color = value ? '#e8e8f0' : '#5a5a78';
  }
}

function countFilledFields(data) {
  return Object.values(data).filter(v => v && v.toString().trim()).length;
}

// ============================
// EXPORT DOCX
// ============================
async function handleExport() {
  if (!extractedData) {
    setStatus('error', 'Chưa có dữ liệu để xuất');
    return;
  }

  setStatus('loading', 'Đang tạo file DOCX...');

  try {
    const templateUrl = chrome.runtime.getURL('template.docx');
    const response = await fetch(templateUrl);

    if (!response.ok) {
      throw new Error('Không thể tải template DOCX');
    }

    const templateBuffer = await response.arrayBuffer();
    const zip = await JSZip.loadAsync(templateBuffer);

    const docXml = await zip.file('word/document.xml').async('string');
    const modifiedXml = replaceDocxPlaceholders(docXml, extractedData);
    zip.file('word/document.xml', modifiedXml);

    const patientName = extractedData.tenDayDu || 'benh_nhan';
    const safeName = patientName.replace(/[^a-zA-Z0-9\s]/g, '').replace(/\s+/g, '_') || 'benh_nhan';
    const fileName = `Phieu_KSK_NCT_${safeName}.docx`;

    // Generate arraybuffer from JSZip
    const arrayBuffer = await zip.generateAsync({ type: 'arraybuffer' });

    // Create blob with correct MIME type
    const blob = new Blob([arrayBuffer], {
      type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    });
    const blobUrl = URL.createObjectURL(blob);

    // Send blob URL to background service worker (which has chrome.downloads)
    chrome.runtime.sendMessage({
      action: 'downloadDocx',
      blobUrl: blobUrl,
      fileName: fileName
    }, (response) => {
      if (response && response.success) {
        setStatus('success', `Đã xuất file: ${fileName}`);
      } else {
        const errMsg = response?.error || chrome.runtime.lastError?.message || 'Unknown';
        console.error('Download failed:', errMsg);
        setStatus('error', 'Lỗi download: ' + errMsg);
      }
      // Clean up blob after delay
      setTimeout(() => URL.revokeObjectURL(blobUrl), 30000);
    });
  } catch (error) {
    console.error('Export error:', error);
    setStatus('error', 'Lỗi xuất file: ' + error.message);
  }
}

/**
 * Fallback download: open file in new tab so user can save
 */
function fallbackDownload(blobUrl, fileName) {
  chrome.tabs.create({ url: blobUrl }, () => {
    setStatus('success', `File mở trong tab mới. Nhấn Cmd+S để lưu: ${fileName}`);
  });
}

/**
 * Replace placeholders in DOCX XML with extracted data.
 * Uses robust paragraph-based approach to handle split runs.
 */
function replaceDocxPlaceholders(xml, data) {
  let day = '', month = '', year = '';
  if (data.ngaySinh && data.ngaySinh.includes('/')) {
    const parts = data.ngaySinh.split('/');
    day = parts[0] || ''; month = parts[1] || ''; year = parts[2] || '';
  } else {
    year = data.namSinh || ''; month = data.thangSinh || '';
  }

  const isMale = data.gioiTinh && data.gioiTinh.toLowerCase().includes('nam');
  const isFemale = data.gioiTinh && (data.gioiTinh.toLowerCase().includes('nữ'));

  const addressParts = [data.soNha, data.xaPhuong, data.tinhTP].filter(Boolean);
  const fullAddress = addressParts.join(', ');

  // === SECTION A ===
  if (data.tenDayDu) xml = appendValueToLabel(xml, 'Họ và tên', data.tenDayDu);

  if (day || month || year) {
    const dateStr = (day || '..') + '/' + (month || '..') + '/' + (year || '....');
    xml = appendValueToLabel(xml, 'Ngày sinh', dateStr);
  }

  if (isMale || isFemale) {
    // Actual XML: <w:t ...>[ ] </w:t></w:r><w:r ...><w:rPr>...</w:rPr><w:t ...>Nam  </w:t>
    // Simple approach: find "[ ] " before "Nam" or "Nữ" and replace with "[X] "
    const target = isMale ? 'Nam' : 'Nữ';
    const cbIdx = xml.indexOf(target);
    if (cbIdx !== -1) {
      // Search backwards from target for "[ ] "
      const searchArea = xml.substring(Math.max(0, cbIdx - 300), cbIdx);
      const bracketIdx = searchArea.lastIndexOf('[ ]');
      if (bracketIdx !== -1) {
        const absIdx = Math.max(0, cbIdx - 300) + bracketIdx;
        xml = xml.substring(0, absIdx) + '[X]' + xml.substring(absIdx + 3);
      }
    }
  }

  if (data.cmnd) xml = appendValueToLabel(xml, 'CMND/CCCD', data.cmnd);
  if (data.danToc) xml = appendValueToLabel(xml, 'Dân tộc', data.danToc);
  if (data.soThe) {
    const cleanBHYT = data.soThe.replace(/\|/g, '');
    xml = appendValueToLabel(xml, 'thẻ BHYT', cleanBHYT);
  }
  if (fullAddress) xml = appendValueToLabel(xml, 'đường phố', fullAddress);
  
  if (data.xaPhuong) xml = appendValueToLabel(xml, 'Xã/Phường', data.xaPhuong);
  if (data.tinhTP) xml = appendValueToLabel(xml, 'Tỉnh/TP', data.tinhTP);
  
  if (data.dienThoaiDiDong) xml = appendValueToLabel(xml, 'động', data.dienThoaiDiDong);

  // === SECTION C ===
  if (data.chieuCao) xml = fillDotsInSameRun(xml, 'Chiều cao:', data.chieuCao);
  if (data.canNang) xml = fillDotsInSameRun(xml, 'Hiện tại:', data.canNang);
  if (data.vongEo) xml = fillDotsInSameRun(xml, 'Vòng bụng:', data.vongEo);
  if (data.mach) xml = fillDotsInSameRun(xml, 'Mạch', data.mach);
  if (data.huyetApTT) {
    xml = fillDotsInSameRun(xml, 'Huyết áp TT', data.huyetApTT);
  }
  if (data.huyetApTTr) xml = fillDotsInSameRun(xml, 'Huyết áp TTr', data.huyetApTTr);
  if (data.nhipTho) xml = fillDotsInSameRun(xml, 'Nhịp thở:', data.nhipTho);

  // === SECTION B ===
  if (data.benhChinh) xml = appendValueToLabel(xml, 'Đang mắc', data.benhChinh);
  if (data.tuVanDieuTri) xml = appendValueToLabel(xml, 'Tư vấn giới thiệu', data.tuVanDieuTri);

  return xml;
}

/**
 * Simply append the value right after the label text in the template.
 * Used when dots have been removed from the template.
 */
function appendValueToLabel(xml, label, value) {
  if (!value) return xml;
  // Escape the label for regex
  const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Replace the first occurrence or all occurrences of the label in a <w:t>
  return xml.replace(
    new RegExp('(<w:t[^>]*>)([^<]*?' + escaped + '[^<]*)(<\\/w:t>)', 'g'),
    (match, tStart, text, tEnd) => {
      // Clean trailing spaces and non-breaking spaces
      let cleanText = text.replace(/[\s\u00A0]+$/, '');
      
      // Ensure there is a colon
      if (!cleanText.endsWith(':') && label !== 'CMND/CCCD') {
        cleanText += ':';
      }
      
      // Append the value with a leading space
      return tStart + cleanText + ' ' + value + tEnd;
    }
  );
}

/**
 * For Section C: dots in same <w:t> with label + unit.
 * e.g. "Chiều cao: ..................cm"
 */
function fillDotsInSameRun(xml, label, value) {
  if (!value) return xml;
  const escaped = escapeRegExp(label);
  return xml.replace(
    new RegExp('(<w:t[^>]*>)(' + escaped + '\\s*)[\\s\u00A0…\\.]{2,}([^<]*)(</w:t>)', 'g'),
    (m, tStart, labelPart, trailing, tEnd) => {
      const unit = trailing.trim();
      const sep = unit ? ' ' : '';
      return tStart + labelPart + ' ' + value + sep + unit + tEnd;
    }
  );
}



function escapeRegExp(str) {
  return str.replace(/[.*+?^${}()|[\]\\\/]/g, '\\$&');
}

// ============================
// STATUS MANAGEMENT
// ============================
function setStatus(type, message) {
  const bar = document.getElementById('statusBar');
  const text = document.getElementById('statusText');
  bar.className = 'status-bar ' + type;
  text.textContent = message;
}
