// Content script for CCCD Extractor
// Listens for messages from popup to extract data from the web form

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractData') {
    try {
      const data = extractFormData();
      sendResponse({ success: true, data: data });
    } catch (error) {
      sendResponse({ success: false, error: error.message });
    }
  }
  return true; // Keep message channel open for async response
});

function extractFormData() {
  const data = {};

  // === TEXT INPUT FIELDS ===
  // Họ và tên
  data.tenDayDu = getInputValue('tenDayDu');
  // Địa chỉ (số nhà)
  data.soNha = getInputValue('soNha');
  // Số điện thoại
  data.dienThoaiDiDong = getInputValue('dienThoaiDiDong');
  // Số CMND/CCCD
  data.cmnd = getInputValue('cmnd');
  // Mã bệnh nhân
  data.maBenhNhan = getInputValue('maBenhNhan');
  // Tên người thân
  data.tenNguoiThan = getInputValue('tenNguoiThan');
  // CMND người thân
  data.cmndNguoiThan = getInputValue('cmndNguoiThan');
  // Điện thoại người thân
  data.dienThoaiNguoiThan = getInputValue('dienThoaiNguoiThan');

  // === SELECT (DROPDOWN) FIELDS ===
  // Giới tính
  data.gioiTinh = getSelectValue('gioiTinh');
  // Tỉnh/TP
  data.tinhTP = getSelectValue('tinhId725');
  // Xã/Phường
  data.xaPhuong = getSelectValue('xaId725');
  // Thôn/Xóm
  data.thonXom = getSelectValue('thonXomId');
  // Dân tộc
  data.danToc = getSelectValue('danTocId');
  // Quốc tịch
  data.quocTich = getSelectValue('quocTichId');
  // Nơi cấp CMND/CCCD
  data.noiCapCmnd = getSelectValue('noiCapCmnd');
  // Nghề nghiệp
  data.ngheNghiep = getSelectValue('ngheNghiepId');
  // Quan hệ (người thân)
  data.quanHe = getSelectValue('quanHeId');
  // Đối tượng
  data.nhomDoiTuong = getSelectValue('nhomDoiTuongId');

  // === DATE FIELDS ===
  // Ngày sinh
  data.ngaySinh = getDateValue('ngaySinh');
  // Năm sinh
  data.namSinh = getInputValueFromContainer('namSinh');
  // Tháng sinh
  data.thangSinh = getInputValueFromContainer('thangSinh');
  // Tuổi
  data.tuoi = getInputValueFromContainer('tuoi');
  // Ngày cấp CMND
  data.ngayCapCmnd = getDateValue('ngayCapCmnd');

  // === BHYT FIELDS ===
  data.soThe = getInputValueFromContainer('soThe');

  // === Nơi làm việc ===
  data.diaChiLamViec = getInputValue('diaChiLamViec') || getInputValueFromContainer('diaChiLamViec');

  return data;
}

/**
 * Get value from a standard text input by name attribute
 */
function getInputValue(fieldName) {
  const input = document.querySelector(`input[name="${fieldName}"]`);
  if (input) {
    return input.value || '';
  }
  return '';
}

/**
 * Get value from an input inside a container identified by nz-col class
 */
function getInputValueFromContainer(fieldName) {
  // Try by container class
  const container = document.querySelector(`.nz-col-${fieldName}`);
  if (container) {
    // Look for text input
    const input = container.querySelector('input.ant-input:not(.ant-select-selection-search-input)');
    if (input) {
      return input.value || '';
    }
    // Look for selected item in nz-select
    const selectItem = container.querySelector('nz-select-item');
    if (selectItem) {
      return selectItem.getAttribute('title') || selectItem.textContent?.trim() || '';
    }
  }
  return '';
}

/**
 * Get the selected value from an nz-select dropdown
 * These use nz-select-item with a title attribute
 */
function getSelectValue(fieldName) {
  // Look for container by nz-col class
  const container = document.querySelector(`.nz-col-${fieldName}`);
  if (container) {
    // nz-select stores selected value in nz-select-item
    const selectItem = container.querySelector('nz-select-item');
    if (selectItem) {
      return selectItem.getAttribute('title') || selectItem.textContent?.trim() || '';
    }

    // Fallback: check for radio buttons or other controls
    const checkedRadio = container.querySelector('input[type="radio"]:checked');
    if (checkedRadio) {
      const label = checkedRadio.closest('label');
      return label ? label.textContent?.trim() : checkedRadio.value;
    }

    // Fallback: look for span with selected text
    const selectedSpan = container.querySelector('.ant-select-selection-item');
    if (selectedSpan) {
      return selectedSpan.getAttribute('title') || selectedSpan.textContent?.trim() || '';
    }
  }
  return '';
}

/**
 * Get value from a date picker field
 */
function getDateValue(fieldName) {
  const container = document.querySelector(`.nz-col-${fieldName}`);
  if (container) {
    // Try the custom ora-input-date first
    const oraInput = container.querySelector('input.ora-input-date');
    if (oraInput && oraInput.value) {
      return oraInput.value;
    }
    // Try the nz-date-picker input
    const dateInput = container.querySelector('.ant-picker-input input');
    if (dateInput && dateInput.value) {
      return dateInput.value;
    }
    // Try any input with date format
    const inputs = container.querySelectorAll('input');
    for (const input of inputs) {
      if (input.value && /\d{2}\/\d{2}\/\d{4}/.test(input.value)) {
        return input.value;
      }
    }
  }
  return '';
}
