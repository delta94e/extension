// CCCD Extractor - Popup Logic
// Handles data extraction from web page and DOCX generation

let extractedData = null;

document.addEventListener('DOMContentLoaded', () => {
  const btnExtract = document.getElementById('btnExtract');
  const btnExport = document.getElementById('btnExport');

  btnExtract.addEventListener('click', handleExtract);
  btnExport.addEventListener('click', handleExport);
});

// ============================
// EXTRACT DATA FROM WEB PAGE
// ============================
async function handleExtract() {
  setStatus('loading', 'Đang trích xuất thông tin...');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab) {
      setStatus('error', 'Không tìm thấy tab đang mở');
      return;
    }

    // Execute content script extraction
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractDataFromPage
    });

    if (results && results[0] && results[0].result) {
      extractedData = results[0].result;
      displayData(extractedData);
      setStatus('success', `Đã trích xuất thành công ${countFilledFields(extractedData)} trường`);
      document.getElementById('btnExport').disabled = false;
    } else {
      setStatus('error', 'Không thể trích xuất dữ liệu. Hãy mở trang tiếp đón bệnh nhân.');
    }
  } catch (error) {
    console.error('Extract error:', error);
    setStatus('error', 'Lỗi: ' + error.message);
  }
}

/**
 * This function runs in the context of the web page (injected)
 */
function extractDataFromPage() {
  const data = {};

  function getInput(name) {
    const el = document.querySelector(`input[name="${name}"]`);
    return el ? el.value || '' : '';
  }

  function getSelect(fieldName) {
    const container = document.querySelector(`.nz-col-${fieldName}`);
    if (container) {
      const item = container.querySelector('nz-select-item');
      if (item) return item.getAttribute('title') || item.textContent?.trim() || '';
      const selectedSpan = container.querySelector('.ant-select-selection-item');
      if (selectedSpan) return selectedSpan.getAttribute('title') || selectedSpan.textContent?.trim() || '';
    }
    return '';
  }

  function getDate(fieldName) {
    const container = document.querySelector(`.nz-col-${fieldName}`);
    if (container) {
      const oraInput = container.querySelector('input.ora-input-date');
      if (oraInput && oraInput.value) return oraInput.value;
      const dateInput = container.querySelector('.ant-picker-input input');
      if (dateInput && dateInput.value) return dateInput.value;
      const inputs = container.querySelectorAll('input');
      for (const input of inputs) {
        if (input.value && /\d{2}\/\d{2}\/\d{4}/.test(input.value)) return input.value;
      }
    }
    return '';
  }

  function getFromContainer(fieldName) {
    const container = document.querySelector(`.nz-col-${fieldName}`);
    if (container) {
      const input = container.querySelector('input.ant-input:not(.ant-select-selection-search-input)');
      if (input) return input.value || '';
      const item = container.querySelector('nz-select-item');
      if (item) return item.getAttribute('title') || item.textContent?.trim() || '';
    }
    return '';
  }

  // Text inputs
  data.tenDayDu = getInput('tenDayDu');
  data.soNha = getInput('soNha');
  data.dienThoaiDiDong = getInput('dienThoaiDiDong');
  data.cmnd = getInput('cmnd');
  data.maBenhNhan = getInput('maBenhNhan');
  data.tenNguoiThan = getInput('tenNguoiThan');
  data.cmndNguoiThan = getInput('cmndNguoiThan');
  data.dienThoaiNguoiThan = getInput('dienThoaiNguoiThan');

  // Select dropdowns
  data.gioiTinh = getSelect('gioiTinh');
  data.tinhTP = getSelect('tinhId725');
  data.xaPhuong = getSelect('xaId725');
  data.thonXom = getSelect('thonXomId');
  data.danToc = getSelect('danTocId');
  data.quocTich = getSelect('quocTichId');
  data.noiCapCmnd = getSelect('noiCapCmnd');
  data.ngheNghiep = getSelect('ngheNghiepId');
  data.quanHe = getSelect('quanHeId');
  data.nhomDoiTuong = getSelect('nhomDoiTuongId');

  // Date fields
  data.ngaySinh = getDate('ngaySinh');
  data.namSinh = getFromContainer('namSinh');
  data.thangSinh = getFromContainer('thangSinh');
  data.tuoi = getFromContainer('tuoi');
  data.ngayCapCmnd = getDate('ngayCapCmnd');

  // Other
  data.soThe = getFromContainer('soThe');
  data.diaChiLamViec = getInput('diaChiLamViec') || getFromContainer('diaChiLamViec');

  return data;
}

// ============================
// DISPLAY EXTRACTED DATA
// ============================
function displayData(data) {
  const section = document.getElementById('dataSection');
  section.style.display = 'block';

  setFieldValue('val_tenDayDu', data.tenDayDu);
  setFieldValue('val_gioiTinh', data.gioiTinh);

  const dateDisplay = data.ngaySinh || [data.thangSinh, data.namSinh].filter(Boolean).join('/');
  setFieldValue('val_ngaySinh', dateDisplay);
  setFieldValue('val_namSinh', data.namSinh);
  setFieldValue('val_cmnd', data.cmnd);
  setFieldValue('val_danToc', data.danToc);
  setFieldValue('val_quocTich', data.quocTich);
  setFieldValue('val_soNha', data.soNha);
  setFieldValue('val_xaPhuong', data.xaPhuong);
  setFieldValue('val_tinhTP', data.tinhTP);
  setFieldValue('val_dienThoaiDiDong', data.dienThoaiDiDong);
  setFieldValue('val_soThe', data.soThe);
  setFieldValue('val_ngheNghiep', data.ngheNghiep);
}

function setFieldValue(id, value) {
  const el = document.getElementById(id);
  if (el) {
    el.textContent = value || '—';
    el.style.color = value ? '#e8e8f0' : '#5a5a78';
  }
}

function countFilledFields(data) {
  return Object.values(data).filter(v => v && v.trim()).length;
}

// ============================
// EXPORT DOCX
// ============================
async function handleExport() {
  if (!extractedData) {
    setStatus('error', 'Chưa có dữ liệu để xuất');
    return;
  }

  setStatus('loading', 'Đang tạo file DOCX...');

  try {
    const templateUrl = chrome.runtime.getURL('template.docx');
    const response = await fetch(templateUrl);

    if (!response.ok) {
      throw new Error('Không thể tải template DOCX');
    }

    const templateBuffer = await response.arrayBuffer();
    const zip = await JSZip.loadAsync(templateBuffer);

    // Read document.xml
    const docXml = await zip.file('word/document.xml').async('string');

    // Replace placeholders
    const modifiedXml = replaceDocxPlaceholders(docXml, extractedData);

    // Update file in zip
    zip.file('word/document.xml', modifiedXml);

    // Generate modified DOCX
    const blob = await zip.generateAsync({
      type: 'blob',
      mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    });

    // Download
    const patientName = extractedData.tenDayDu || 'benh_nhan';
    const safeName = patientName.replace(/[^a-zA-ZÀ-ỹ0-9\s]/g, '').replace(/\s+/g, '_');
    const fileName = `Phieu_KSK_NCT_${safeName}.docx`;

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setStatus('success', `Đã xuất file: ${fileName}`);
  } catch (error) {
    console.error('Export error:', error);
    setStatus('error', 'Lỗi xuất file: ' + error.message);
  }
}

/**
 * Replace placeholders in DOCX XML with extracted data.
 *
 * The template DOCX has structure like:
 *   <w:t>Họ và tên:</w:t> ... <w:t>\u00A0…………</w:t>
 *   <w:t>[ ] </w:t> ... <w:t>Nam  </w:t>
 *   <w:t>Số CMND/CCCD: </w:t> ... <w:t>……………………</w:t>
 *
 * Strategy: Use direct string replacement on the XML, targeting the
 * dot/placeholder <w:t> elements that follow each label.
 */
function replaceDocxPlaceholders(xml, data) {
  // Parse date
  let day = '', month = '', year = '';
  if (data.ngaySinh && data.ngaySinh.includes('/')) {
    const parts = data.ngaySinh.split('/');
    day = parts[0] || '';
    month = parts[1] || '';
    year = parts[2] || '';
  } else {
    year = data.namSinh || '';
    month = data.thangSinh || '';
  }

  // Gender
  const isMale = data.gioiTinh && data.gioiTinh.toLowerCase().includes('nam');
  const isFemale = data.gioiTinh && (data.gioiTinh.toLowerCase().includes('nữ') || data.gioiTinh.toLowerCase() === 'nữ');

  // Build address
  const addressParts = [data.soNha, data.xaPhuong, data.tinhTP].filter(Boolean);
  const fullAddress = addressParts.join(', ');

  // =============================================
  // REPLACEMENTS - Using regex on raw XML
  // =============================================

  // 1. Họ và tên: replace dots after label
  if (data.tenDayDu) {
    xml = replaceDotsAfterLabel(xml, 'Họ và tên:', data.tenDayDu);
  }

  // 2. Ngày sinh: replace dots between slashes
  if (day || month || year) {
    const dateStr = `${day || '..'}/${month || '..'}/${year || '....'}`;
    xml = replaceDateSection(xml, dateStr);
  }

  // 3. Giới tính: replace [ ] with [X]
  if (isMale) {
    // Find "[ ] " before "Nam" and replace with "[X] "
    xml = xml.replace(
      /(<w:t[^>]*>)\[\s*\]\s*(<\/w:t><\/w:r>(?:<w:r[^>]*>(?:<w:rPr>[\s\S]*?<\/w:rPr>)?)?<w:t[^>]*>Nam)/,
      '$1[X] $2'
    );
  } else if (isFemale) {
    // Find "[ ] " before "Nữ" and replace with "[X] "
    xml = xml.replace(
      /(<w:t[^>]*>)\[\s*\]\s*(<\/w:t><\/w:r>(?:<w:r[^>]*>(?:<w:rPr>[\s\S]*?<\/w:rPr>)?)?<w:t[^>]*>Nữ)/,
      '$1[X] $2'
    );
  }

  // 4. Số CMND/CCCD
  if (data.cmnd) {
    xml = replaceDotsAfterLabel(xml, 'Số CMND/CCCD:', data.cmnd);
    // Also replace "Số CMND/CCCD:\u00A0" variant
    xml = replaceDotsAfterLabel(xml, 'Số CMND/CCCD:\u00A0', data.cmnd);
  }

  // 5. Dân tộc
  if (data.danToc) {
    xml = replaceDotsAfterLabel(xml, 'Dân tộc', data.danToc);
  }

  // 6. Số thẻ BHYT
  if (data.soThe) {
    xml = replaceDotsAfterLabel(xml, 'Số thẻ BHYT', data.soThe);
  }

  // 7. Nơi đăng ký thường trú - the address with dots
  if (fullAddress || data.soNha) {
    xml = replaceDotsInSameElement(xml, 'Nơi đăng ký thường trú', fullAddress || data.soNha);
  }

  // 8. Xã/Phường - replace dots
  if (data.xaPhuong) {
    xml = replaceDotsInSameElement(xml, 'Xã/Phường:', data.xaPhuong);
  }

  // 9. Tỉnh/TP
  if (data.tinhTP) {
    xml = replaceDotsAfterLabel(xml, 'Tỉnh/TP:', data.tinhTP);
    xml = replaceDotsInSameElement(xml, 'Tỉnh/TP:', data.tinhTP);
  }

  // 10. Điện thoại di động
  if (data.dienThoaiDiDong) {
    xml = replaceDotsAfterLabel(xml, 'Điện thoại', data.dienThoaiDiDong);
  }

  return xml;
}

/**
 * Replace dot placeholders in <w:t> elements that follow a label.
 * The DOCX structure puts the label in one <w:r> and dots in subsequent <w:r> elements.
 *
 * Pattern: <w:t>Label</w:t></w:r><w:r ...><w:t>……………</w:t>
 */
function replaceDotsAfterLabel(xml, label, value) {
  if (!value) return xml;

  const escapedLabel = escapeRegExp(label);

  // Find the label in a <w:t>, then replace the FIRST following <w:t> that contains only dots
  // Pattern: label in <w:t>, close run, open new run, <w:t> with dots
  const pattern = new RegExp(
    '(' + escapedLabel + '</w:t></w:r>' +           // Label + close
    '<w:r[^>]*>(?:<w:rPr>[\\s\\S]*?</w:rPr>)?)' +  // Open next run + optional rPr
    '<w:t[^>]*>[\\s\u00A0…\\.]{2,}</w:t>',           // <w:t> with dots
    ''
  );

  const replaced = xml.replace(pattern, (match, prefix) => {
    return prefix + `<w:t xml:space="preserve"> ${value}</w:t>`;
  });

  // If replaced, clear subsequent dot runs in the same paragraph
  if (replaced !== xml) {
    return clearRemainingDotsInParagraph(replaced, label, value);
  }

  return replaced;
}

/**
 * Replace dots that are in the SAME <w:t> element as the label.
 * Pattern: <w:t>Xã/Phường: ………………</w:t>
 */
function replaceDotsInSameElement(xml, label, value) {
  if (!value) return xml;

  const escapedLabel = escapeRegExp(label);

  // Pattern: label followed by dots in the same <w:t>
  const pattern = new RegExp(
    '(<w:t[^>]*>)(' + escapedLabel + '\\s*)[\\s\u00A0…\\.]{2,}(</w:t>)',
    'g'
  );

  return xml.replace(pattern, (match, tStart, labelPart, tEnd) => {
    return `${tStart}${labelPart}${value}${tEnd}`;
  });
}

/**
 * After replacing the first dot run after a label, clear any remaining
 * dot-only <w:t> elements in the same paragraph to avoid leftover dots.
 */
function clearRemainingDotsInParagraph(xml, label, value) {
  // Find the paragraph containing the label
  const labelIdx = xml.indexOf(value);
  if (labelIdx === -1) return xml;

  // Find the paragraph end (</w:p>) after the label
  const pEnd = xml.indexOf('</w:p>', labelIdx);
  if (pEnd === -1) return xml;

  // Get the segment between the inserted value and paragraph end
  const before = xml.substring(0, labelIdx + value.length);
  let after = xml.substring(labelIdx + value.length, pEnd);
  const rest = xml.substring(pEnd);

  // Replace remaining dot-only <w:t> elements with empty ones
  after = after.replace(
    /<w:t[^>]*>[\s\u00A0…\.]{2,}<\/w:t>/g,
    '<w:t></w:t>'
  );

  return before + after + rest;
}

/**
 * Replace the date section (Ngày sinh: ……/…./………)
 * The date is split across multiple runs with slashes
 */
function replaceDateSection(xml, dateStr) {
  // Find "Ngày sinh:" or "Ngày sinh: " then replace all following dot+slash runs
  const nsIdx = xml.indexOf('Ngày sinh:');
  if (nsIdx === -1) return xml;

  // Find the end of the paragraph containing "Ngày sinh:"
  const pEnd = xml.indexOf('</w:p>', nsIdx);
  if (pEnd === -1) return xml;

  // Get paragraph segment after the label
  const labelEndIdx = nsIdx + 'Ngày sinh:'.length;
  const segBefore = xml.substring(0, labelEndIdx);
  let segment = xml.substring(labelEndIdx, pEnd);
  const segAfter = xml.substring(pEnd);

  // Strategy: Find the first <w:t> after the label that has content (dots or space),
  // replace it with our date, and clear all subsequent dot/slash <w:t>s
  // until we hit "Giới tính" or paragraph end
  let firstReplaced = false;
  const gioiTinhIdx = segment.indexOf('Giới tính');
  const endBound = gioiTinhIdx !== -1 ? gioiTinhIdx : segment.length;
  const relevantSegment = segment.substring(0, endBound);
  const afterRelevant = segment.substring(endBound);

  const modifiedSegment = relevantSegment.replace(
    /(<w:t[^>]*>)([\s\u00A0…\.\/]+)(<\/w:t>)/g,
    (match, tStart, content, tEnd) => {
      if (!firstReplaced) {
        firstReplaced = true;
        return `<w:t xml:space="preserve"> ${dateStr}</w:t>`;
      }
      // Clear subsequent dot/slash runs
      return '<w:t></w:t>';
    }
  );

  return segBefore + modifiedSegment + afterRelevant + segAfter;
}

/**
 * Escape special regex characters in a string
 */
function escapeRegExp(str) {
  return str.replace(/[.*+?^${}()|[\]\\\/]/g, '\\$&');
}

// ============================
// STATUS MANAGEMENT
// ============================
function setStatus(type, message) {
  const bar = document.getElementById('statusBar');
  const text = document.getElementById('statusText');
  bar.className = 'status-bar ' + type;
  text.textContent = message;
}
